# Windows20
Windows Server 2019 Github with RDP Access (ngrok US) 

Disclaimer:- THIS RDP IS WORK FOR 6 HOURS

Create a free VPS with 2cpu-7gb Ram FREE with Github:

+ Click Fork in the right corner of the screen to save it to your Github.
+ Visit https://dashboard.ngrok.com to get NGROK_AUTH_TOKEN
+ In Github go to Settings> Secrets> New repository secret
+ In Name: enter NGROK_AUTH_TOKEN
+ In Value: visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste Your Authtoken into
+ Press Add secret
+ Go to Action> henil_is_owner> Run workflow
+ Reload the page and press henil_is_owner> build
+ Press the down arrow of Assign User on Connect To Your RPD to get User, Password.
+ If you want see a video how to get rdp for 6 hours i giving a link:- https://youtu.be/UCtUVYX0jG0
+ enjoy 🥳🥳
