$i = 361
do {
    Write-Host $i
    Sleep 180
    $i--
} while ($i -gt 0)
